module.exports = (req, res, next) => {
    if (false) {
        console.log('working');
        return res.redirect('/login');
    }
    next();
}